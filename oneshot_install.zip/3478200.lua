addappid(3478200) -- Trilogy of the Moon
-- MAIN APP DEPOTS
addappid(3478201, 1, "03bb32be6195269cf7e30a1f0ba4207cf42c817b2d0c70f7eb87e9529c0875a5") -- Depot 3478201
--setManifestid(3478201, "38066385038200383", 10248591969)
-- DLCS WITH DEDICATED DEPOTS
-- Trilogy of the Moon - The First Fate (AppID: 3668590)
addappid(3668590)
addappid(3668591, 1, "53da152a23648f9a6c8487d0ec9d4334e1bde5cfc26482026e41494bc1827b1f") -- Trilogy of the Moon - The First Fate - Depot 3668591
--setManifestid(3668591, "1164163854019272211", 6824403226)