addappid(1272080, 1, "936ace676b0f55735b99f0fa85ec0f7591457b37170bd6fde4e6c1527cbcfcec") -- PAYDAY 3
-- MAIN APP DEPOTS
addappid(1272081, 1, "3e032aede34266458c52fd8d6bd33c4505bc1742e2cdbba706fe9746a83059fa") -- Depot 1272081
setManifestid(1272081, "3992291735437096658", 81309616084)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2438800) -- PAYDAY 3 - Trifecta Lootbag
addappid(2442890) -- PAYDAY 3 - Dark Sterling Mask
addappid(2449350) -- PAYDAY 3 - Gold Slate Gloves
addappid(2449351) -- PAYDAY 3 - Skull of Liberty Mask
addappid(2450690) -- PAYDAY 3 Syntax Error Heist
addappid(2450691) -- PAYDAY 3 Syntax Error Weapon Pack
addappid(2450692) -- PAYDAY 3 Syntax Error Tailor Pack
addappid(2450693) -- PAYDAY 3 Boys in Blue Heist
addappid(2450694) -- PAYDAY 3 Boys in Blue Weapon Pack
addappid(2450695) -- PAYDAY 3 Boys in Blue Tailor Pack
addappid(2450696) -- PAYDAY 3 Houston Breakout Heist
addappid(2450697) -- PAYDAY 3 Houston Breakout Weapon Pack
addappid(2450711) -- PAYDAY 3 Year 1 Pass
addappid(2713010) -- PAYDAY 3 Chapter 1 - Syntax Error
addappid(3055010) -- PAYDAY 3  Chapter 2 - Boys in Blue
addappid(3110530) -- PAYDAY 3 Chapter 3 - Houston Breakout
addappid(3111880) -- PAYDAY 3 Houston Breakout Tailor Pack
addappid(3128380) -- PAYDAY 3 Preacher Pack
addtoken(3128380, "6750075724610993843")
addappid(3128390) -- PAYDAY 3 Heavy Hitter Pack
addtoken(3128390, "17518054095715756082")
addappid(3128400) -- PAYDAY 3 Drifter Pack
addtoken(3128400, "2208606941206783081")
addappid(3128410) -- PAYDAY 3 Assassin Pack
addtoken(3128410, "8894736172595126731")
addappid(3128420) -- PAYDAY 3 Island Skin
addtoken(3128420, "2905822885284622007")
addappid(3171970) -- PAYDAY 3 Chapter 4 - Fear  Greed
addappid(3171980) -- PAYDAY 3 Fear  Greed Heist
addappid(3171990) -- PAYDAY 3 Fear  Greed Weapon Pack
addappid(3172010) -- PAYDAY 3 Fear  Greed Tailor Pack
addappid(3214920) -- PAYDAY 3 Houston Character Pack
addappid(3450550) -- PAYDAY 3 Jacket Character Pack
addappid(3679630) -- PAYDAY 3 Party Powder Heist
addappid(3858460) -- PAYDAY 3 Delivery Charge Heist
addappid(4129170) -- PAYDAY 3 Shopping Spree Heist