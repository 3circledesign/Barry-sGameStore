addappid(2300120) -- Painkiller
-- MAIN APP DEPOTS
addappid(2300122, 1, "564f6b9b6546324d5955cca4017995913ecaa47e114dc895936fa767f514a829") -- Depot 2300122
--setManifestid(2300122, "4702260100840626704", 27665825845)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
--setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
--setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3751350) -- Painkiller Iron Crusade Pack
addappid(3751360) -- Painkiller Night Watch Pack
addappid(3751400) -- Painkiller Season Pass