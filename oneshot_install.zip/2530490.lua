addappid(2530490) -- Lost Eidolons: Veil of the Witch
-- MAIN APP DEPOTS
addappid(2530491, 1, "7edbb8d7ab46a4c9dd432e79bd83ff5fa540cd15144a384e599065a20590d31d") -- Depot 2530491
--setManifestid(2530491, "1811563967989648976", 4695831233)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(4021450) -- Lost Eidolons Veil of the Witch - Main Character Skin Set