-- Generated Lua Manifest by Solus Bot in Morrenus Games
-- Steam App 1071870 Manifest
-- Name: Biped
-- Generated: 2025-06-05 00:29:46
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(1071870) -- Biped

-- MAIN APP DEPOTS
addappid(1071871, 1, "d6f3b571a1143307c6948afc03f2d3da402871af1602410cf9e270d993eeb303") -- Biped_Test
setManifestid(1071871, "7542808206490832843", 0)

-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 0)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 0)
