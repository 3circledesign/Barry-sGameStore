addappid(3841040) -- Lilialette's Hustle: Getting My Hands Dirty to Save My Guild
-- MAIN APP DEPOTS
addappid(3841041, 1, "6d15598413bf053028a36a33683d9a19533c0a95b8da544feec001da7b954000") -- Depot 3841041
--setManifestid(3841041, "5115204722523802296", 842171719)