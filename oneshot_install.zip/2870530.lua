-- 2870530's Lua and Manifest Created by Morrenus
-- Battle Suit Aces
-- Created: October 09, 2025 at 00:01:48 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2870530) -- Battle Suit Aces
-- MAIN APP DEPOTS
addappid(2870531, 1, "ef0f08514098789e750352a93e39be905ffd94e115b0f1af85ebcf67a662e3c4") -- Depot 2870531
--setManifestid(2870531, "8099048149993625628", 1487546973)