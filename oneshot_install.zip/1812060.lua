-- 1812060's Lua and Manifest Created by Morrenus
-- Yokai Art: Night Parade of One Hundred Demons
-- Created: October 01, 2025 at 08:45:33 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 3
-- Total DLCs: 2

-- MAIN APPLICATION
addappid(1812060) -- Yokai Art: Night Parade of One Hundred Demons
-- MAIN APP DEPOTS
addappid(1812061, 1, "3ae5d631e032bf802fcaec330f910b43a08cf26f476f47d1e8658e5811ef7d84") -- Depot 1812061
--setManifestid(1812061, "4416213533646514854", 3535567796)
-- DLCS WITH DEDICATED DEPOTS
-- Yokai Art  Adult Content Patch (AppID: 2072470)
addappid(2072470, 1, "23b865f9503a0a67865b872de0f2d1d86737a85c38cc551be031e076b70fad17")
addappid(2072470, 1, "23b865f9503a0a67865b872de0f2d1d86737a85c38cc551be031e076b70fad17") -- Yokai Art  Adult Content Patch - Depot 2072470
--setManifestid(2072470, "3870107595646724767", 3823844580)
-- Yokai Art  Endless Four Seasons DLC (AppID: 2256730)
addappid(2256730, 1, "58fbc71b420a736c818ef341ac9b7e0d91ab22fa1b9a5ee866050aea46c2244f")
addappid(2256730, 1, "58fbc71b420a736c818ef341ac9b7e0d91ab22fa1b9a5ee866050aea46c2244f") -- Yokai Art  Endless Four Seasons DLC - Depot 2256730
--setManifestid(2256730, "1202545975063566408", 3535567796)
