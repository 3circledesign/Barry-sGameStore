-- 2904000's Lua and Manifest Created by Hubcap Manifest
-- The Spell Brigade
-- Created: April 29, 2026 at 10:48:00 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 2 (1 excluded)
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(2904000, 1, "53f59ea61a3ed7df3bc6f763f4269312f95253c67f375a1778fdda6e3f35344b") -- The Spell Brigade
-- MAIN APP DEPOTS
addappid(2904001, 1, "1cea3f47529b0e53e7add1f7e63dcdf14634adfde24faf952128ad1034ee90e8") -- Depot 2904001
setManifestid(2904001, "2126123740719590084", 3206502176)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3194200) -- The Spell Brigade - Supporter Pack
addappid(4235530) -- The Spell Brigade - Disciples of Solphish Skin Pack
-- EXCLUDED DLCS:
-- DLCS EXCLUDED (MISSING DEPOT KEYS)
-- The Spell Brigade - Digital Artbook (AppID: 4457550) - missing depot keys
-- addappid(4457550)