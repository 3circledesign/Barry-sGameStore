-- 1094600's Lua and Manifest Created by Morrenus
-- Kingdom of Night
-- Created: December 05, 2025 at 23:48:21 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1094600) -- Kingdom of Night
-- MAIN APP DEPOTS
addappid(1094601, 1, "18da74b260b5418fae1ef0bda9efa4f94e46ac6676e440789c724f4e73b66b23") -- Depot 1094601
--setManifestid(1094601, "3952767605789951475", 570094578)