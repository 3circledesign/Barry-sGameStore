addappid(3748780) -- Tales Of Glory 3 : Fists of Legend
-- MAIN APP DEPOTS
addappid(3748781, 1, "0f84b24c4588276c6ccd37aacdc7e37d7781d69e781cc7b8c7d924b693ea603f") -- Depot 3748781
--setManifestid(3748781, "7534849078765538939", 39832372102)