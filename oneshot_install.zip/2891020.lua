addappid(2891020) -- Undusted: Letters from the Past
-- MAIN APP DEPOTS
addappid(2891021, 1, "a90ed813e052210c9fcfb1c1b5198e4859120ad61da4afeeba57383d1829cdc0") -- Depot 2891021
--setManifestid(2891021, "5126379838689604401", 1398199422)
-- EXCLUDED DLCS:
-- DLCS EXCLUDED (MISSING DEPOT KEYS)
-- Undusted Letters from the Past Artbook (AppID: 3904790) - missing depot keys
-- addappid(3904790)