addappid(4071080) -- Monsters Hate Only the Princess
-- MAIN APP DEPOTS
addappid(4071081, 1, "50232d300504d242157876483bb98f7862c1da6c2bf1bf35b7f3abcb20573a26") -- Depot 4071081
--setManifestid(4071081, "266694310851793925", 198331053)