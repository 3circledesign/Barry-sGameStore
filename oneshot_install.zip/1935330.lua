-- 1935330's Lua and Manifest Created by Morrenus
-- SOPA - Tale of the Stolen Potato
-- Created: October 09, 2025 at 07:31:43 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1935330) -- SOPA - Tale of the Stolen Potato
-- MAIN APP DEPOTS
addappid(1935331, 1, "22e384213a619f10645da6428c611dd5a8d2893dc4763df24ee44f6bad051a87") -- Depot 1935331
--setManifestid(1935331, "6851621888665120335", 2728486253)