-- 1380060's Lua and Manifest Created by Morrenus
-- Urban Trial Tricky
-- Created: October 01, 2025 at 05:04:45 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1380060) -- Urban Trial Tricky
-- MAIN APP DEPOTS
addappid(1380061, 1, "c63269098d395526b3e7e903548359d329da7e656bb8d92d2e8d69194cac11f9") -- Urban Trial Tricky Content
--setManifestid(1380061, "4438897293212685067", 1097941013)