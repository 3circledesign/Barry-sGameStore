addappid(3717330) -- Yakuza Kiwami
-- MAIN APP DEPOTS
addappid(3717331, 1, "0ae165b84122aca403f33db5776efe0b7470e19c5dd5f3049ad9b0a149bebc86") -- Depot 3717331
--setManifestid(3717331, "4081106027113997373", 32414290613)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
--setManifestid(228989, "3514306556860204959", 39590283)