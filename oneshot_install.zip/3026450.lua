addappid(3026450) -- Deadly Days: Roadtrip
-- MAIN APP DEPOTS
addappid(3026451, 1, "08c7847ddefdede391a0d5886f7e7029e4cc96283420ac285db7a14f73bee64b") -- Depot 3026451
--setManifestid(3026451, "1832737755528485607", 0)
addappid(3026452, 1, "a41650ee622aa1fc85f5322dd7230a5daa51913e5d70decb5bb52ebdc6bca2c3") -- Depot 3026452
--setManifestid(3026452, "5337153435707454857", 1074208811)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
--setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
--setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3883820) -- Supporter Pack