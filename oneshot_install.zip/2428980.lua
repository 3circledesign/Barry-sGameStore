addappid(2428980) -- Bye Sweet Carole
-- MAIN APP DEPOTS
addappid(2428983, 1, "4459aa4e531d8007450e4a278ffab68b61d229d38bc1801993ed63bd4275d455") -- Depot 2428983
--setManifestid(2428983, "5626474517239673432", 15641127065)
-- EXCLUDED DLCS:
-- DLCS EXCLUDED (MISSING DEPOT KEYS)
-- Bye Sweet Carole - Artbook (AppID: 3902770) - missing depot keys
-- addappid(3902770)