addappid(1794880) -- Ys vs. Trails in the Sky: Alternative Saga
-- MAIN APP DEPOTS
addappid(1794881, 1, "66219f904250a46bd95e70bb6a48bd2a28abe64e749052b1142b56e8e17affc1") -- Depot 1794881
--setManifestid(1794881, "7403318515552649465", 6209703866)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
--setManifestid(228989, "3514306556860204959", 39590283)
-- DLCS WITH DEDICATED DEPOTS
-- Ys vs. Trails in the Sky Alternative Saga - Digital Art Book (AppID: 4049770)
addappid(4049770)
addappid(4049770, 1, "a225e9f9a9d1844088f5a0184e840c37a4c1379d335d28eb6ee3554da6606c8c") -- Ys vs. Trails in the Sky Alternative Saga - Digital Art Book - Depot 4049770
--setManifestid(4049770, "3813417149367988105", 103301302)