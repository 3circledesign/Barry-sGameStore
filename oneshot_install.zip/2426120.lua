addappid(2426120) -- Concubine
-- MAIN APP DEPOTS
addappid(2426121, 1, "58e1dc6ebd8a0dd2d1605f224e3f7edd77e05c8102d86feb8525eceff2a22f2f") -- Depot 2426121
--setManifestid(2426121, "2180394121246228028", 6544746874)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
--setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
--setManifestid(228990, "1829726630299308803", 102931551)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- .NET 4.8 Redist (Shared from App 228980)
--setManifestid(229007, "4477590687906973371", 117381405)