addappid(243450) -- Urban Trial Freestyle
-- MAIN APP DEPOTS
addappid(243451, 1, "d4e85fa02923b97b6620f0b145eaeeaf0c66ddc52db941b22249395006d728c1") -- Urban Trials Content
--setManifestid(243451, "2889074021562158281", 626458076)
-- SHARED DEPOTS (from other apps)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
--setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(249700) -- Urban Trial Freestyle Special Rider Suit DLC 