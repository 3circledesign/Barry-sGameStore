addappid(3112260) -- Virtua Fighter 5 R.E.V.O. World Stage
-- MAIN APP DEPOTS
addappid(3112261, 1, "e6f1715a5b59614a89b1dd93f5b2f9c4078e5365b885651d49acfbfc4df8ad89") -- Depot 3112261
setManifestid(3112261, "458315324348140584", 29613551635)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- Virtua Fighter 5 R.E.V.O. World Stage - Pre-Production Artbook (AppID: 3419340)
addappid(3419340)
addappid(3419340, 1, "4b3635250f8302c53596898e27b028d2c0f4a1a05b4c29578ce06a634e9a1663") -- Virtua Fighter 5 R.E.V.O. World Stage - Pre-Production Artbook - Depot 3419340
setManifestid(3419340, "1269275464081308678", 551460704)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3282760) -- Virtua Fighter 5 R.E.V.O. World Stage - Yakuza Series Collaboration Pack DLC
addappid(3282770) --  Virtua Fighter 5 R.E.V.O. World Stage - Virtua Fighter Legendary Pack DLC
addappid(3282780) -- Virtua Fighter 5 R.E.V.O. World Stage - TEKKEN 7 Collaboration Pack DLC
addappid(3353780) -- Virtua Fighter 5 R.E.V.O. World Stage - Special Pre-order Bonus
addappid(3353790) -- Virtua Fighter 5 R.E.V.O. World Stage - 30th Anniversary Edition Bonus Contents
addappid(3761410) -- Virtua Fighter 5 R.E.V.O. World Stage - Dural
-- EMPTY DEPOTS (no content on any branch)
-- addappid(3353790) -- Depot 3353790 (empty depot)