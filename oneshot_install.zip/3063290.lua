-- 3063290's Lua and Manifest Created by Morrenus
-- 我的同學是女優
-- Created: October 02, 2025 at 15:25:08 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3063290) -- 我的同學是女優
-- MAIN APP DEPOTS
addappid(3063291, 1, "c63caa02484f0c39b3ee396cbc4befcccdaac5f291e3204792d96f556226ed20") -- Depot 3063291
--setManifestid(3063291, "4309826831735379775", 2274823778)