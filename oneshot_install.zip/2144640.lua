addappid(2144640, 1, "7ca07b384ee60a80dd525456c888cf96619c7dad0c985f1d3fc0ec77c2ebeb9c") -- Endzone 2
-- MAIN APP DEPOTS
addappid(2144641, 1, "0a49695ed1feda3f6ad84629f01e5139b5793585af34810d1dbd600c5236c9bf") -- Depot 2144641
--setManifestid(2144641, "6444503200931762384", 7002223702)
-- DLCS WITH DEDICATED DEPOTS
-- Endzone 2 Artbook (AppID: 3124440)
addappid(3124440)
addappid(3124440, 1, "5e5fe8829907e57c8d5c1c7a4fe0b54508623d0209237e8d2a11f073beae7932") -- Endzone 2 Artbook - Depot 3124440
--setManifestid(3124440, "8072980921453709180", 48519040)
-- Endzone 2 Wallpaper Pack (AppID: 3142480)
addappid(3142480)
addappid(3142480, 1, "4ea89a642735f6b393f43e6955abb72aa78b652ee20420c3d874ddd29d1f9b96") -- Endzone 2 Wallpaper Pack - Depot 3142480
--setManifestid(3142480, "9043632041574392878", 1253268112)