addappid(3570370) -- CARIMARA: Beneath the forlorn limbs
-- MAIN APP DEPOTS
addappid(3570372, 1, "09523c1d6511cd6591b36ed5b1d224329294afacd7ec947d803c269eeae1da68") -- Depot 3570372
--setManifestid(3570372, "1423791342513120192", 734566606)
addappid(3570373, 1, "4b19ddee3140df89a7334f21dc87be2ecebf8aa3acde63ecca13292eb2e694b5") -- Depot 3570373
--setManifestid(3570373, "29460777853865779", 740265232)