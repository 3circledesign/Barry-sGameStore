addappid(7770)
addappid(7771)
addappid(7771,0,"5c7bf4532a5f40a416c3d2f0f2a1b2596f5414ee6dd0bfdc95747ffd989d8fe4")
setManifestid(7771,"754232656957845730")
