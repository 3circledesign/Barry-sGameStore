addappid(347670) -- Karate Master 2 Knock Down Blow
-- MAIN APP DEPOTS
addappid(347671, 1, "01504f734d199d864133be14f8eee7c23bddb08c14d30d6b62f6a44d4c724fb7") -- Karate Master 2 Knock Down Blow Content
--setManifestid(347671, "956711886882580479", 417463934)