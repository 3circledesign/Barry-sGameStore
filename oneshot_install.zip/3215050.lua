addappid(3215050, 1, "0c12d7c521db27fbcb262b9dceaf4515edc8461a750843e31bd2cc70aecc0d32") -- Surviving Mars: Relaunched
-- MAIN APP DEPOTS
addappid(3215051, 1, "528e1024e8c79853eb462f95a4032f940ecfe198d66e55d5941e6b3607aa6261") -- Depot 3215051
--setManifestid(3215051, "1560833379137171802", 9370938798)
addappid(3215052, 1, "36502842caf9feaf6353ca0352b3a67c56dadb515b72f3ae130716975e906cb3") -- Depot 3215052
--setManifestid(3215052, "1850466033052604865", 413662095)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
--setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
--setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- Surviving Mars Relaunched - Interplanetary Codex - Mission Sponsor (AppID: 3889420)
addappid(3889420)
addappid(3889420, 1, "8395176ed107aae69fa70d830384ab151bc7d9a58ecd8b5514f4448c9ec260d5") -- Surviving Mars Relaunched - Interplanetary Codex - Mission Sponsor - Depot 3889420
--setManifestid(3889420, "8430645401184820024", 7134363)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3889470) -- Surviving Mars Relaunched - Prime Mission