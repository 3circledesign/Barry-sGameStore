addappid(3580580) -- Jacksmith: Weapons and Warriors
-- MAIN APP DEPOTS
addappid(3580581, 1, "66b3c25e35e2d734a6591131492f846958fed2a8c5b0a1a4e44a9195f6f78866") -- Depot 3580581
--setManifestid(3580581, "161179547877802750", 45688133)