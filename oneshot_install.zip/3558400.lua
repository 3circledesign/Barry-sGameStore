addappid(3558400) -- Backseat Drivers
-- MAIN APP DEPOTS
addappid(3558401, 1, "99209e260c4664fddb750252e28e3ddbb84ffa4cded64191f9c52cfd74778a32") -- Depot 3558401
--setManifestid(3558401, "7382962546169821027", 1822061251)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
--setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
--setManifestid(228990, "1829726630299308803", 102931551)