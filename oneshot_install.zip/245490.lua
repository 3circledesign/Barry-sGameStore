addappid(245490) -- Trials Fusion
-- MAIN APP DEPOTS
addappid(245491, 1, "e44218247bc22153f73511eb618b0364fb6007571dbba9879087eaef3b6b8cfe") -- Trials Fusion Content
--setManifestid(245491, "4307533748747045843", 11197436555)
-- SHARED DEPOTS (from other apps)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- VC 2008 Redist (Shared from App 228980)
--setManifestid(228982, "6413394087650432851", 9688647)
addappid(1716751, 1, "84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675") -- Ubisoft Connect PC Client Content (Shared from App 1716750)
--setManifestid(1716751, "818295193716041715", 632424)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(287330) -- Trials Fusion Season Pass
addappid(287410) -- Trials Fusion - Standard Edition
addappid(287411) -- Trials Fusion - Deluxe Edition
addappid(297600) -- Trials Fusion - Preorder - Standard Edition
addappid(297601) -- Trials Fusion - Preorder - Deluxe Edition
addappid(311550) -- Trials Fusion - Riders of the Rustlands
addappid(311551) -- Trials Fusion Empire of Sky DLC2
addappid(326170) -- Trials Fusion - Welcome to the Abyss
addappid(337740) -- Trials Fusion - Fault one zero
addappid(337750) -- Trials Fusion - Fire in the Deep
addappid(355770) -- Trials Fusion - After the Incident
addappid(381840) -- Trials Fusion - Awesome Level Max