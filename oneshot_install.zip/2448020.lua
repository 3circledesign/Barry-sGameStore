-- 2448020's Lua and Manifest Created by Morrenus
-- Yooka-Replaylee
-- Created: October 09, 2025 at 11:57:10 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2448020) -- Yooka-Replaylee
-- MAIN APP DEPOTS
addappid(2448021, 1, "0087364299b86dce13084a6e34fc1292ca9587691740ac9b8b93fe737b8af5b0") -- Depot 2448021
--setManifestid(2448021, "8203004014523827167", 27508372948)