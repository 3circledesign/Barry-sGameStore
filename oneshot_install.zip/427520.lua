addappid(427520, 1, "31ecbbd55ffe883e0c7014eb69a61e3fd85b18ce745b2d50d0b87825c74578b4") -- Factorio
-- MAIN APP DEPOTS
addappid(427521, 1, "313aabe725a369c7112e56db4fb78556f9fe5d8a1e599833000c4b3a29ceb0f4") -- Factorio Win64
setManifestid(427521, "3717738577353096913", 2234454105)
addappid(427522, 1, "e595c19750b6343a6790b2d19c9edd29f5f910dbd5d5d98d42944bb3474342f5") -- Factorio Win32
setManifestid(427522, "8127115610667035850", 488882534)
addappid(427523, 1, "da6be217fa0d138b92f96b6f6a825fe3d0d271bfe7125601eaa4f66c818ceecb") -- Factorio Linux64
setManifestid(427523, "4487506071215585729", 2032439389)
addappid(427524, 1, "3b9ae6dba8cff0e5061fa6c28a67f22b7750064913db9499570a9e8edaa29aac") -- Factorio Linux32
setManifestid(427524, "2006867560965339051", 362494820)
addappid(427525, 1, "4cf6a64823e9240f302d20a5428fdade384b312b0f55c87aaebd14bf62beb353") -- Factorio OSX
setManifestid(427525, "5752599812311446640", 2585457058)
-- DLCS WITH DEDICATED DEPOTS
-- Factorio Space Age (AppID: 645390)
addappid(645390)
addappid(645391, 1, "e1e840cb840b8d382a84e6cc0443393d76f99ab19ee8afd3a61a0b414fc5ac9f") -- Factorio Space Age - Factorio: Space Age
setManifestid(645391, "3084651630676717196", 4829764966)
addappid(645392, 1, "a7b9074d3a2634bc9163847fe1ae9cfb0ad55a286a6c32b67289f2a07e2e654f") -- Factorio Space Age - Factorio: Space Age
setManifestid(645392, "7097471955963626949", 5384827312)
addappid(645393, 1, "df5808d5e8ae3a9cce0454d6f6968c6f200e4d28a4cd2a4ba4f8be1426ad7ff4") -- Factorio Space Age - Factorio: Space Age
setManifestid(645393, "5964184531172431537", 5031854390)