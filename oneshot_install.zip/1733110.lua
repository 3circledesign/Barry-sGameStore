addappid(1733110, 1, "6c3007e160b8db8a1534cdc04cac231c5c141e4e9b82978d69a5070e6d012665") -- Of Life and Land
-- MAIN APP DEPOTS
addappid(1733111, 1, "2aefb5610aff8c017b461ec4f3da8d7a17a426b0d4ab6bf30df2bd99c391e208") -- Depot 1733111
--setManifestid(1733111, "3760157127671171480", 606130998)
addappid(1733112, 1, "c8a5dfd8f65bf5c949c255c8fca8b013076e98f57ade13f59f7109a416664253") -- Depot 1733112
--setManifestid(1733112, "2845130169606121565", 615614783)
-- DLCS WITH DEDICATED DEPOTS
-- Of Life and Land - Supporter Pack (AppID: 2885390)
addappid(2885390)
addappid(2885390, 1, "f576d68dd367d474b2cab70ca21aa4b1ea75eacc3fbf41c70eb2913bb1c8541d") -- Of Life and Land - Supporter Pack - Depot 2885390
--setManifestid(2885390, "2309400059646761733", 313904200)