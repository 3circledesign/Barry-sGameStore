addappid(3265060) -- 东方异域见闻 ~ Touhou Dystopian
-- MAIN APP DEPOTS
addappid(3265061, 1, "9ba6d456be5b82db0d49f0bf2a7d03212edadfd8348df2d7844433fb1a6c590a") -- Depot 3265061
--setManifestid(3265061, "9191767081222538854", 9244905582)