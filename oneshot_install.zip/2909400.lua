addappid(2909400) -- FINAL FANTASY VII REBIRTH
-- MAIN APP DEPOTS
addappid(2909401, 1, "7ab31662f5cf76b4197f27c340a2a0589dc4713c137aadfd22b281df42c07a56") -- Depot 2909401
setManifestid(2909401, "6351449259010459507", 164861796166)
addappid(2909402, 1, "fd15686ace81b2e7a839997e1bcc40d7dd9c15f49ce21714252771aa357fd67f") -- Depot 2909402
setManifestid(2909402, "8874976628106391332", 22139806937)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- FINAL FANTASY VII REBIRTH Digital Mini Soundtrack  Digital Art Book (AppID: 3260630)
addappid(3260630)
addappid(3260630, 1, "39c8633805b12cb219e18d1665139d9ff5dd2a8ad30517ce3b29f1f935641f61") -- FINAL FANTASY VII REBIRTH Digital Mini Soundtrack  Digital Art Book - Depot 3260630
setManifestid(3260630, "2312058563762645934", 41)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3260650) -- FINAL FANTASY VII REBIRTH Summon materia Moogle trio
addappid(3260660) -- FINAL FANTASY VII REBIRTH Summon materia Magic Pot
addappid(3260670) -- FINAL FANTASY VII REBIRTH Accessory Reclaimant Choker
addappid(3260680) -- FINAL FANTASY VII REBIRTH Armor Orchid Bracelet
addappid(3312260) -- FINAL FANTASY VII REBIRTH Posh Chocobo Summoning Materia
addappid(3312270) -- FINAL FANTASY VII REBIRTH Armor Shinra Bangle Mk. II
addappid(3312280) -- FINAL FANTASY VII REBIRTH Armor Midgar Bangle Mk. II
addappid(3361450) -- FINAL FANTASY VII REBIRTH Digital Deluxe Edition Upgrade
addappid(3376810) -- FINAL FANTASY VII REBIRTH Accessory Kupo Charm  Survival Set