addappid(2695430) -- AILA
-- MAIN APP DEPOTS
addappid(2695431, 1, "059aa71cb66544e31c563e0bcc18b9bab023a8fa58ce942eeb07ce7f3f170eed") -- Depot 2695431
--setManifestid(2695431, "4140553972379632999", 20600009743)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
--setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
--setManifestid(228990, "1829726630299308803", 102931551)