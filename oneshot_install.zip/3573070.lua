-- 3573070's Lua and Manifest Created by Morrenus
-- Toy Smash Kaboom!
-- Created: December 05, 2025 at 06:20:33 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3573070) -- Toy Smash Kaboom!
-- MAIN APP DEPOTS
addappid(3573072, 1, "ce783d1006f1ac72cd284f8bf3a1c09dae93b32eac38e46f46996f5104db4930") -- Depot 3573072
--setManifestid(3573072, "2424779162016034592", 667882260)