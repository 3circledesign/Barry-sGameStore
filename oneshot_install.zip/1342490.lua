addappid(1342490, 1, "23dd752c2a079cb0e28aacc6cc7286c228f93bf412691cfa6fa8d112d56ed876") -- Daemon X Machina: Titanic Scion
-- MAIN APP DEPOTS
addappid(1342491, 1, "c6540bdf8c309fb168778b2fbe5a1f6fd5802ca36eb9ac410f78e2bce2d4b57f") -- Depot 1342491
setManifestid(1342491, "5092541211047703933", 52127527271)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- Daemon X Machina Titanic Scion - Art Book (AppID: 3779150)
addappid(3779150)
addappid(3779150, 1, "7f846f37bcfb01890a3bf2c2a91724c2342f38d3085da2354f573476227b405b") -- Daemon X Machina Titanic Scion - Art Book - Depot 3779150
setManifestid(3779150, "951698471833675111", 520153184)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3766420) -- Daemon X Machina Titanic Scion - Additional Emote - Fist Pump
addappid(3766430) -- Daemon X Machina Titanic Scion - Additional Emote - Roar
addappid(3766440) -- Daemon X Machina Titanic Scion - Special Equipment Set
addappid(3766450) -- Daemon X Machina Titanic Scion - Bonus Item Set
addappid(3766470) -- Daemon X Machina Titanic Scion - Additional Hairstyle - Punk
addappid(3766530) -- Daemon X Machina Titanic Scion - Additional Hairstyle - Giant Mohawk
addappid(3766550) -- Daemon X Machina Titanic Scion - Special SFX Weapon Set
addappid(3766560) -- Daemon X Machina Titanic Scion - Arsenal Skin Set
addappid(3766570) -- Daemon X Machina Titanic Scion - Emote Set
addappid(3817280) -- Daemon X Machina Titanic Scion - Free Formal Suit Outfit
addappid(3817290) -- Daemon X Machina Titanic Scion - Free Reclaimer Outfit
addappid(3817300) -- Daemon X Machina Titanic Scion - Free Axiom Researcher Outfit
addappid(3817320) -- Daemon X Machina Titanic Scion - Free Iris Outfit
addappid(3817330) -- Daemon X Machina Titanic Scion - Reclaimers Outfit Set
addappid(3817340) -- Daemon X Machina Titanic Scion - Sovereign Axiom Outfit Set
addappid(3817350) -- Daemon X Machina Titanic Scion - Hairstyle Set 1
addappid(3817360) -- Daemon X Machina Titanic Scion - Hairstyle Set 2
addappid(3817370) -- Daemon X Machina Titanic Scion - Hairstyle Set 3
addappid(3817390) -- Daemon X Machina Titanic Scion - Hairstyle Set 4
addappid(3817400) -- Daemon X Machina Titanic Scion - Hairstyle Set 5
addappid(3817410) -- Daemon X Machina Titanic Scion - Hairstyle Set 6
addappid(3817420) -- Daemon X Machina Titanic Scion - Hairstyle Set 7
addappid(3817430) -- Daemon X Machina Titanic Scion - Hairstyle Set 8
addappid(3817440) -- Daemon X Machina Titanic Scion - Avatar Customization Pack 1
addappid(3817450) -- Daemon X Machina Titanic Scion - Avatar Customization Pack 3
addappid(3817460) -- Daemon X Machina Titanic Scion - Avatar Customization Pack 2
addappid(3817470) -- Daemon X Machina Titanic Scion - Avatar Customization Pack 4
addappid(3817480) -- Daemon X Machina Titanic Scion - Avatar Customization Pack 5
addappid(3817490) -- Daemon X Machina Titanic Scion - Grand Entrance Set 1
addappid(3817500) -- Daemon X Machina Titanic Scion - Grand Entrance Set 2
addappid(3817510) -- Daemon X Machina Titanic Scion - Vehicle Set
addappid(3817520) -- Daemon X Machina Titanic Scion - Decal Set
addappid(3817530) -- Daemon X Machina Titanic Scion - Stamp Set
addappid(3817540) -- Daemon X Machina Titanic Scion - Into the Abyss
addappid(3974080) -- Daemon X Machina Titanic Scion - Free Hairstyles
addappid(3974090) -- Daemon X Machina Titanic Scion - Free Emotes
-- EXCLUDED DLCS:
-- UNRELEASED DLCS (COMMENTED OUT)
-- addappid(3787730) -- Daemon X Machina: Titanic Scion - Deluxe Edition Content Map (unreleased)