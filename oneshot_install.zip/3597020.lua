addappid(3597020) -- Becoming a King
-- MAIN APP DEPOTS
addappid(3597021, 1, "c19caf5a7bf6c6240363c9aebdf31b185b4cc2662397ce352678f0bdaaadc35a") -- Depot 3597021
--setManifestid(3597021, "9043454255360608214", 6231400776)
-- DLCS WITH DEDICATED DEPOTS
-- Becoming a King - Digital Artbook (AppID: 4072680)
addappid(4072680)
addappid(4072681, 1, "b33d16c5a46f12a5fc1af82f4fd123e3f75c596bcc9efe23e6376faee44f7bda") -- Becoming a King - Digital Artbook - Depot 4072681
--setManifestid(4072681, "496602665802719239", 321168079)
-- Becoming a King - Animations Pack (AppID: 4072690)
addappid(4072690)
addappid(4072691, 1, "960f2399eb302a6e01aab03a900a1cc77a631b95101e9dad3164313cff1f4ff0") -- Becoming a King - Animations Pack - Depot 4072691
--setManifestid(4072691, "7939445868875113236", 10356604176)
-- Becoming a King - Wallpapers Pack (AppID: 4072700)
addappid(4072700)
addappid(4072701, 1, "da0aeb851d78091cf5a2542a7bc098fb34915d32d991d38e86359a614bc4a5f0") -- Becoming a King - Wallpapers Pack - Depot 4072701
--setManifestid(4072701, "4745372408192038845", 238596512)