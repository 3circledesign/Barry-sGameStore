-- 1904480's Lua and Manifest Created by Morrenus
-- Absolum
-- Created: October 09, 2025 at 12:01:01 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 2
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(1904480) -- Absolum
-- MAIN APP DEPOTS
addappid(1904481, 1, "119d51fd44dd8198b1a6c12a73e3943c8587d93e990f15b7453404b51a8ce4f3") -- Depot 1904481
--setManifestid(1904481, "9031483967879991195", 4691453681)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
--setManifestid(228989, "3514306556860204959", 39590283)