-- 2000120's Lua and Manifest Created by Morrenus
-- Time Flies
-- Created: October 02, 2025 at 15:21:21 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2000120) -- Time Flies
-- MAIN APP DEPOTS
addappid(2000122, 1, "b242fb4e4a021b7afbaf4855dafa847dafdb7db983443c53407101ae039af249") -- Depot 2000122
--setManifestid(2000122, "4217657198512764081", 210492313)