addappid(2627260, 1, "0a892e3e526a787e9c75452994764a88a34e66b7eac52146fd250a7223dfb182") -- Ninja Gaiden 4
-- MAIN APP DEPOTS
addappid(2627261, 1, "1dbbfa4a1302ac713af5d572bd94e7d0708ba581ca184c4124588ff3fdc06481") -- Depot 2627261
setManifestid(2627261, "6644170988571432626", 67150210842)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3717100) -- NINJA GAIDEN 4 Deluxe Edition Content
addappid(3717110) -- NINJA GAIDEN 4 Dark Dragon Descendant Yakumo Skin
addappid(4191490) -- NINJA GAIDEN 4 The Two Masters
-- EMPTY DEPOTS (no content on any branch)
-- addappid(2627262) -- Depot 2627262 (empty depot)
-- addappid(3322910) -- Depot 3322910 (empty depot)