addappid(2005870) -- House of Necrosis
-- MAIN APP DEPOTS
addappid(2005871, 1, "35b1e993213eef34407edff5f626cd07f75be033b8b3e4d79df37e60b07d3ade") -- Depot 2005871
--setManifestid(2005871, "4993064282227069169", 315493772)