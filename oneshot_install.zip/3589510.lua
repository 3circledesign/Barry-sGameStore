addappid(3589510) -- Returns Outlet Simulator
-- MAIN APP DEPOTS
addappid(3589511, 1, "76623ef6a219f0ca46fe23e2b675eeee9da252b1d03ec4c4a13e194696ba6d8a") -- Depot 3589511
--setManifestid(3589511, "4134170036052836441", 5466853621)