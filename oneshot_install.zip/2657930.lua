addappid(2657930) -- Erannorth Renaissance
-- MAIN APP DEPOTS
addappid(2657931, 1, "8d44fa8772bff2e387fd4080bcacccf39d0b51760808c9bc78e6c447dfe7a32b") -- Depot 2657931
--setManifestid(2657931, "2771782198641194148", 1378806885)