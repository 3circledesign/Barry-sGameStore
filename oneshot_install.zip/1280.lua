addappid(1280)
addappid(1281)
setManifestid(1281,"5786003204048175177")