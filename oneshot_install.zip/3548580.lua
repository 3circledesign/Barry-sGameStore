addappid(3548580) -- Chill with You Lo-Fi Story
-- MAIN APP DEPOTS
addappid(3548581, 1, "4bd410e2ecc28dd07ee6d887a275a6b32edaeca1e6d401ccab204fe35bd9b99d") -- Depot 3548581
--setManifestid(3548581, "1851526857350481872", 967193144)