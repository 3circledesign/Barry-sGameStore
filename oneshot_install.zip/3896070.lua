addappid(3896070) -- 30 minutes until my brain dies
-- MAIN APP DEPOTS
addappid(3896072, 1, "0eb35e8ee2b5cc1abee142b83c12bc5f2433968608078740aead76a07819c3a4") -- Depot 3896072
--setManifestid(3896072, "3107048370868657895", 666981320)