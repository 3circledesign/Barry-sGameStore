-- 3259600's Lua and Manifest Created by Morrenus
-- Atelier Resleriana: The Red Alchemist & the White Guardian
-- Created: October 05, 2025 at 23:22:18 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 7
-- Total DLCs: 6 (1 excluded)
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(3259600) -- Atelier Resleriana: The Red Alchemist & the White Guardian
-- MAIN APP DEPOTS
addappid(3259601, 1, "ae634a9eec6e2ae45901364376e5c088e269ae26071c8b7741b4a9b681bdf85c") -- Depot 3259601
--setManifestid(3259601, "5203110445657579825", 11427647952)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
--setManifestid(228988, "6645201662696499616", 29212173)
-- DLCS WITH DEDICATED DEPOTS
-- The Red Alchemist  the White Guardian - Digital Deluxe Pack (AppID: 3811090)
addappid(3811090)
addappid(3811090, 1, "c6402a39e57409af780a6941b3eb551458899ac990877fc4eae4085a0e6cd963") -- The Red Alchemist  the White Guardian - Digital Deluxe Pack - Depot 3811090
--setManifestid(3811090, "2644734002309645064", 8140471)
-- The Red Alchemist  the White Guardian - Rough Time Costume Set for Rias and Slade (AppID: 3811100)
addappid(3811100)
addappid(3811100, 1, "4c981d6c3b8f831fbb44d55631fb10454974be174034b5ca814d4eea4d3d4141") -- The Red Alchemist  the White Guardian - Rough Time Costume Set for Rias and Slade - Depot 3811100
--setManifestid(3811100, "4256506066546908639", 947578)
-- The Red Alchemist  the White Guardian - Activewear Adventuring Set (AppID: 3811110)
addappid(3811110)
addappid(3811110, 1, "fdb0f863798896be92f76b7738c9a5e7a6c9b6616d4afd4e28216cbae0aa631f") -- The Red Alchemist  the White Guardian - Activewear Adventuring Set - Depot 3811110
--setManifestid(3811110, "5582534334480437529", 0)
-- The Red Alchemist  the White Guardian - Alchemist of Memories Costumes for Rias and Slade (AppID: 3811130)
addappid(3811130)
addappid(3811130, 1, "3b21d7253db784922ca1da073dc42392f86a5587d1df1ed179a785d0a566e4bd") -- The Red Alchemist  the White Guardian - Alchemist of Memories Costumes for Rias and Slade - Depot 3811130
--setManifestid(3811130, "1319099733821752758", 1256563)
-- The Red Alchemist  the White Guardian - Gust Extra BGM Pack (AppID: 3811180)
addappid(3811180)
addappid(3811180, 1, "1b0ebc42b6b1c083f7dc0eaa131088d447042cd8e0d680f449dd3a8e00e79ac0") -- The Red Alchemist  the White Guardian - Gust Extra BGM Pack - Depot 3811180
--setManifestid(3811180, "8214049227113093791", 1074647077)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3811120) -- The Red Alchemist  the White Guardian - Atelier Season Pass
-- EXCLUDED DLCS:
-- DLCS EXCLUDED (MISSING DEPOT KEYS)
-- The Red Alchemist  the White Guardian - Midnight Costume Set Early Distribution Costumes for Rias and Slade (AppID: 3811080) - missing depot keys
-- addappid(3811080)