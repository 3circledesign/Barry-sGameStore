-- 3668370's Lua and Manifest Created by Morrenus
-- Night Swarm
-- Created: December 18, 2025 at 01:37:38 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3668370) -- Night Swarm
-- MAIN APP DEPOTS
addappid(3668371, 1, "980df52f8f9145bce6710c1de03dd3e91fce5c30ba47bf36ef798b1217b54718") -- Depot 3668371
--setManifestid(3668371, "6620364879742489582", 1879083496)