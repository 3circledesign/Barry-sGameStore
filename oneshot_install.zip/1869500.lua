addappid(1869500) -- Daimon Blades
-- MAIN APP DEPOTS
addappid(1869501, 1, "49e36947f4a3b33907fb520e27d8d33ffd54d90fdbb2a3e7963d99f0397314bf") -- Depot 1869501
--setManifestid(1869501, "6863398332544561710", 21977914298)
addappid(1869502, 1, "08c7109feb33d3890e12f11a03df0ef36a7b49cad594b25bc01a8fcd29f1b251") -- Depot 1869502
--setManifestid(1869502, "1892717862217796817", 644789312)
addappid(1869503, 1, "81d11a35c7a9beda96bc3d64012f32ec8893d8f44afe03de656db7e260fd8a94") -- Depot 1869503
--setManifestid(1869503, "4705580345408001261", 0)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
--setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
--setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- Daimon Blades - Secreta Secretorum DLC (AppID: 2885420)
addappid(2885420)
addappid(2885420, 1, "9fd4e6d4f3b45d2e42cdec1ad8f7bf86d3675f9a277bea722b5dd151d2f07006") -- Daimon Blades - Secreta Secretorum DLC - Depot 2885420
--setManifestid(2885420, "4272660389331277730", 54290345)