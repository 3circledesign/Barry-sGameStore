-- Generated Lua Manifest by Solus Bot in Morrenus Games
-- Steam App 1220140 Manifest
-- Name: Cartel Tycoon
-- Generated: 2025-06-05 03:42:10
-- Total Depots: 6
-- Total DLCs: 6 (1 excluded)
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(1220140) -- Cartel Tycoon

-- MAIN APP DEPOTS
addappid(1220141, 1, "8c5dc498da79909bd350403d6063a625fca9a48f93e0f87d6fe1b2f0f5b23df2") -- Cartel Tycoon Content
setManifestid(1220141, "5349864675858905113", 0)

-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 0)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 0)

-- DLCS WITH DEDICATED DEPOTS
-- Cartel Tycoon - Soundtrack Vol. II (AppID: 2020980)
addappid(2020980)
addappid(2020981, 1, "15785f59715c5f3dda78e735c7f7802314aafdd61da5e4f6e3fb75518cc4f54c") -- Cartel Tycoon - Soundtrack Vol. II - Main Content
setManifestid(2020981, "4823513579452936973", 0)
addappid(2020982, 1, "1c87613a6ce5ba1c22bcdf731d1e36862167478fb51b84c49fa19800c13dad12") -- Cartel Tycoon - Soundtrack Vol. II - Main Content
setManifestid(2020982, "3682251999419219289", 0)

-- Cartel Tycoon Artbook (AppID: 2081480)
addappid(2081480)
addappid(2081480, 1, "dde87e84b645ae58d3c159b3dfa18bdd7a6c72d4da4c969a29ded7bf364a0e6e") -- Cartel Tycoon Artbook - Main Content
setManifestid(2081480, "3344072352565673020", 0)

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2081450) -- Cartel Tycoon - Lieutenants Pack - Guerillas
addappid(2316200) -- Cartel Tycoon - Lieutenants Pack - La Familia
addappid(2348770) -- Cartel Tycoon San Rafaela
addappid(2827980) -- Cartel Tycoon Content Pack - Divas Hotel

-- DLCS EXCLUDED (NO DEPOT KEYS, NO DEDICATED DEPOTS)
-- addappid(1570090) -- Cartel Tycoon Soundtrack (no keys available)
