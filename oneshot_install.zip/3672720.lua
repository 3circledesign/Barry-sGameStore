-- 3672720's Lua and Manifest Created by Hubcap Manifest
-- Prison Escape Simulator: Dig Out
-- Created: April 18, 2026 at 14:32:38 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3672720, 1, "4a1336c4fb38d8d313365c0fbaafd93a946e8df55e0c6a607babfb6f0c88f35b") -- Prison Escape Simulator: Dig Out
-- MAIN APP DEPOTS
addappid(3672722, 1, "9b3449633eddd535ba0aa2b2b242cbe7f1bbedf545cec40ef03704ea188b19f7") -- Depot 3672722
setManifestid(3672722, "9045095195754328504", 9158610113)
addappid(3672723, 1, "5593eabd7a1b8562686afc1e18f41bbecffdacd9fd4a45e2ff681eeb0c2719cd") -- Depot 3672723
setManifestid(3672723, "7082533711530245574", 9159272308)