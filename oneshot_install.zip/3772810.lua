addappid(3772810) -- Desktop Defender
-- MAIN APP DEPOTS
addappid(3772811, 1, "11705aad35c8ebad27db5190cb0ba455f9cffce599edd17206f7b4494bbcbccc") -- Depot 3772811
--setManifestid(3772811, "1791297551466889525", 180627179)