addappid(3592140) -- Anima Gate of Memories: I & II Remastered
-- MAIN APP DEPOTS
addappid(3592141, 1, "a040de4449456b56aeda4c798644fb890eee25da530a3d16a616f4725edfd7d7") -- Depot 3592141
--setManifestid(3592141, "3216633980700572997", 19768704833)