-- 3464370's Lua and Manifest Created by Morrenus
-- Sani Yang's Laboratory
-- Created: October 03, 2025 at 06:20:29 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 2
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(3464370) -- Sani Yang's Laboratory
-- MAIN APP DEPOTS
addappid(3464371, 1, "975aa052f081c26d62a27cc774a31e174b701e4987b947bd07b78aa4310923ef") -- Depot 3464371
--setManifestid(3464371, "939924712131301109", 13194261123)
-- DLCS WITH DEDICATED DEPOTS
-- Sani Yangs Laboratory - Secret Plus (AppID: 4013190)
addappid(4013190)
addappid(4013190, 1, "e14f78d85d28f4e32d346012d1e772808782a846e0c066d8511667a894925618") -- Sani Yangs Laboratory - Secret Plus - Depot 4013190
--setManifestid(4013190, "8843656416377518425", 278519642)