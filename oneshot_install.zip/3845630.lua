addappid(3845630) -- The Taming Massage Parlor ~Mari's Story~
-- MAIN APP DEPOTS
addappid(3845631, 1, "70c1bbe573f72d38b50981c9efcb0d9d379b2f85940ce6364f94c37a83182f44") -- Depot 3845631
--setManifestid(3845631, "1466300500558557568", 582488155)