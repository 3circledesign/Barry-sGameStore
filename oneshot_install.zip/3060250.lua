addappid(3060250) -- Tropical Monster Girls
-- MAIN APP DEPOTS
addappid(3060251, 1, "10faf374ab755aee0b0b7ee8cca6ecda9f081c2ea84dda8884ea9ff1333ebcc8") -- Depot 3060251
--setManifestid(3060251, "6048763090228271791", 2808218629)