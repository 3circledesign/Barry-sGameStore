-- 3060250's Lua and Manifest Created by Morrenus
-- Tropical Monster Girls
-- Created: October 04, 2025 at 01:50:56 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3060250) -- Tropical Monster Girls
-- MAIN APP DEPOTS
addappid(3060251, 1, "10faf374ab755aee0b0b7ee8cca6ecda9f081c2ea84dda8884ea9ff1333ebcc8") -- Depot 3060251
--setManifestid(3060251, "6048763090228271791", 2808218629)