addappid(3932990) -- Nun of your Business
-- MAIN APP DEPOTS
addappid(3932991, 1, "55a8f2e2020efee4bd0e2196eff3da1c17fdc7fa8e4ddf9f5af985a781859aee") -- Depot 3932991
--setManifestid(3932991, "6908212257222451241", 7407741916)