addappid(2699950) -- Rated Sudoku
-- MAIN APP DEPOTS
addappid(2699951, 1, "2a2804af8dbc93917145f5cddbed6ffb4d177056f24d1b24fbc14c1ef4ecb41a") -- Depot 2699951
--setManifestid(2699951, "3183755736875384074", 282464536)