addappid(668430) -- V-Racer Hoverbike
-- MAIN APP DEPOTS
addappid(668431, 1, "a700820d5fd00fad0c0a86d33150808c20584f592402cd3f8c7395667940ad47") -- V-Racer Hoverbike Content
--setManifestid(668431, "826543637713600300", 6991059693)