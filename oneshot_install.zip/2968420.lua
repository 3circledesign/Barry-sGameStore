addappid(2968420, 1, "d67e90e69712a46a9aeb2fc1e684d7432a88cd41dad7fbce89e0005ceb3b1322") -- PowerWash Simulator 2
-- MAIN APP DEPOTS
addappid(2968422, 1, "2c13dcc1b498282fe021b2cd49229d7309ace370d9e990cd3ad843397cf247c9") -- Depot 2968422
setManifestid(2968422, "206880034470160536", 9254162368)
-- EXCLUDED DLCS:
-- UNRELEASED DLCS (COMMENTED OUT)
-- addappid(4173830) -- PowerWash Simulator 2 - Adventure Time Pack (unreleased)
-- EMPTY DEPOTS (no content on any branch)
-- addappid(4173830) -- Depot 4173830 (empty depot)
-- addappid(4229450) -- Depot 4229450 (empty depot)