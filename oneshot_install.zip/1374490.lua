addappid(1374490, 1, "735dc070f781ea410ecf7ffbdf051b5fdb8d98ea6054aa34aea78625b4a3e594") -- RuneScape: Dragonwilds
-- MAIN APP DEPOTS
addappid(1374491, 1, "e1a3b5ad6a0fbda32b1fceadce8be5fe365e6c98dcc654bfdef62b6aa01f48d5") -- Depot 1374491
setManifestid(1374491, "6570616224743756509", 27885170605)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3501790) -- RuneScape Dragonwilds Early Adopter DLC