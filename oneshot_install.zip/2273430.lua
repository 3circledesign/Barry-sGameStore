-- 2273430's Lua and Manifest Created by Morrenus
-- BlazBlue Entropy Effect
-- Created: March 16, 2026 at 06:46:03 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 4
-- Total DLCs: 6
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(2273430, 1, "74c56cf61e5a97b6195c5ffbb90ff0e2d2fef3c6db31611a575cfca82250ef25") -- BlazBlue Entropy Effect
addtoken(2273430, "16677277415782867963")
-- MAIN APP DEPOTS
addappid(2273431, 1, "8208c2f3da1d2334a1bdfdce064948df43608a9dce229fd006defc11ec0bb5ff") -- Depot 2273431
setManifestid(2273431, "4133228959767029577", 15368217526)
addappid(2273432, 1, "61cf08549f627caaf2793f6324710aa2bc1e9ce5b15ddd5f91a07fe323c89cef") -- Depot 2273432
setManifestid(2273432, "6165169653357104761", 15418432299)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
-- DLCS WITH DEDICATED DEPOTS
-- BlazBlue Entropy Effect - Launch Exclusive Content (AppID: 2771130)
addappid(2771130)
addappid(2771130, 1, "9252ee34ddef99b9842cf9b953a265b23f119aac46977475999deac055a2aa24") -- BlazBlue Entropy Effect - Launch Exclusive Content - Depot 2771130
setManifestid(2771130, "3519795565238480803", 998060164)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3085820) --  BlazBlue Entropy Effect - Rachel Character Pack
addappid(3422870) -- BlazBlue Entropy Effect - Hazama Character Pack
addappid(3681910) -- BlazBlue Entropy Effect - Bullet Character Pack
addappid(4212180) -- BlazBlue Entropy Effect - Naoto Character Pack
addappid(4372140) -- BlazBlue Entropy Effect [X-File] Palette Set