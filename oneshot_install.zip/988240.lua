addappid(988240) -- Urban Trial Playground
-- MAIN APP DEPOTS
addappid(988241, 1, "7967b4167b90376ca7c29c46f6553c022b9722e114401da5aed6e675fc68f474") -- Urban Trial Playground Content
--setManifestid(988241, "943918896516663580", 17670091614)
addappid(988242, 1, "213b94d4c1cf169e0f20eb80afd48b4cf3390ec0bd3c6fc8adb02f8fb9a72553") -- Urban Trial Playground Linux
--setManifestid(988242, "6563387308252829466", 19342527024)
addappid(988243, 1, "0db457f4f311ce1cf78cd9bb0c66f43dce004790a2135f28f13a6237b0829a57") -- Urban Trial Playground Mac
--setManifestid(988243, "2023699156687788896", 22355316135)
-- SHARED DEPOTS (from other apps)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
--setManifestid(228986, "8782296191957114623", 29759921)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
--setManifestid(228990, "1829726630299308803", 102931551)