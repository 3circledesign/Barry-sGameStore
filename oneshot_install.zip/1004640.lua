addappid(1004640) -- FINAL FANTASY TACTICS - The Ivalice Chronicles
-- MAIN APP DEPOTS
addappid(1004641, 1, "b9ffdc9182829343bcdf50e8c3fe66b2fc58fbbe11980078cfc04e6f8d91701d") -- Depot 1004641
--setManifestid(1004641, "3851313839159942687", 10954171381)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3589750) -- FINAL FANTASY TACTICS - The Ivalice Chronicles Pre-order Bonuses
addappid(3589760) -- FINAL FANTASY TACTICS - The Ivalice Chronicles Deluxe Edition Bonuses