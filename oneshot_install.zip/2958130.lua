addappid(2958130) -- Jurassic World Evolution 3
-- MAIN APP DEPOTS
addappid(2958131, 1, "dc7cb4cb8d7d76fdcab84fed34fa1f799e7459cf1be5ed041116ed846211889d") -- Depot 2958131
--setManifestid(2958131, "6616524064629033442", 21349093879)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
--setManifestid(228989, "3514306556860204959", 39590283)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3651190) -- Jurassic World Evolution 3 Badlands Set
addappid(3651200) -- Jurassic World Evolution 3 Deluxe Upgrade Pack