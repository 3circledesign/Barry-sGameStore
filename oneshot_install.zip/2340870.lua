addappid(2340870) -- Rugby 25
-- MAIN APP DEPOTS
addappid(2340871, 1, "93ccfe6514668e6f5b1c0a8ab689650f762c3a6e18e7f21627be8e47f475801d") -- Depot 2340871
--setManifestid(2340871, "699637747992693007")
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
--setManifestid(228989, "3514306556860204959", 39590283)