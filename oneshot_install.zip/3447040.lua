addappid(3447040) -- Sora no Kiseki the 1st
-- MAIN APP DEPOTS
addappid(3447041, 1, "1094c51be1905bc44cf99ef97fa418199a8907734568008f95c100371af927f7") -- Depot 3447041
--setManifestid(3447041, "3972286517635792134", 30451973045)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3944980) -- Sora no Kiseki the 1st - Estelle  Joshua Swimwear Pure Resort
addappid(3944990) -- Sora no Kiseki the 1st - Jenis Royal Academy Uniform Set
addappid(3945000) -- Sora no Kiseki the 1st - Matching Diner Costume Set Fine Red Diner Vol.1
addappid(3945010) -- Sora no Kiseki the 1st - Matching Diner Costume Set Fine Red Diner Vol.2
addappid(3945020) -- Sora no Kiseki the 1st - Matching Diner Costume Set Fine Red Diner Vol.3
addappid(3945030) -- Sora no Kiseki the 1st - Unique Diner Costume Set Vol.1
addappid(3945040) -- Sora no Kiseki the 1st - Unique Diner Costume Set Vol.2
addappid(3945050) -- Sora no Kiseki the 1st - Unique Diner Costume Set Vol.3
addappid(3945060) -- Sora no Kiseki the 1st - Glasses Set A
addappid(3945070) -- Sora no Kiseki the 1st - Glasses Set B
addappid(3945080) -- Sora no Kiseki the 1st - Go for it Headgear Set
addappid(3945090) -- Sora no Kiseki the 1st - Head-Pom Set A
addappid(3945100) -- Sora no Kiseki the 1st - Head-Pom Set B
addappid(3945110) -- Sora no Kiseki the 1st - Chocosta Set
addappid(3945120) -- Sora no Kiseki the 1st - Pretty Backpack Set
addappid(3945130) -- Sora no Kiseki the 1st - Archangel Costume Set
addappid(3945140) -- Sora no Kiseki the 1st - Fallen Angel Costume Set
addappid(3945150) -- Sora no Kiseki the 1st - Demon King Costume Set
addappid(3945160) -- Sora no Kiseki the 1st - Lively Effect Set
addappid(3945170) -- Sora no Kiseki the 1st - Banner Set A
addappid(3945180) -- Sora no Kiseki the 1st - Banner Set B
addappid(3945190) -- Sora no Kiseki the 1st - Banner Set C
addappid(3945200) -- Sora no Kiseki the 1st - Two-Tone Hair Color Set
addappid(3945210) -- Sora no Kiseki the 1st - Unique Hair Color Set
addappid(3945220) -- Sora no Kiseki the 1st - Orbment Cover Set
addappid(3945230) -- Sora no Kiseki the 1st - Chibi Character Cover Set
addappid(3945240) -- Sora no Kiseki the 1st - Sepith Set (1)
addappid(3945250) -- Sora no Kiseki the 1st - Sepith Set (2)
addappid(3945260) -- Sora no Kiseki the 1st - Sepith Set (3)
addappid(3945270) -- Sora no Kiseki the 1st - Sepith Set (4)
addappid(3945280) -- Sora no Kiseki the 1st - Sepith Set (5)
addappid(3945290) -- Sora no Kiseki the 1st - U-Material Set (1)
addappid(3945300) -- Sora no Kiseki the 1st - U-Material Set (2)
addappid(3945310) -- Sora no Kiseki the 1st - U-Material Set (3)
addappid(3945320) -- Sora no Kiseki the 1st - U-Material Set (4)
addappid(3945330) -- Sora no Kiseki the 1st - U-Material Set (5)
addappid(3945340) -- Sora no Kiseki the 1st - Monster Ingredients Set A (1)
addappid(3945360) -- Sora no Kiseki the 1st - Monster Ingredients Set A (2)
addappid(3945370) -- Sora no Kiseki the 1st - Monster Ingredients Set A (3)
addappid(3945380) -- Sora no Kiseki the 1st - Monster Ingredients Set B (1)
addappid(3945390) -- Sora no Kiseki the 1st - Monster Ingredients Set B (2)
addappid(3945400) -- Sora no Kiseki the 1st - Monster Ingredients Set B (3)
addappid(3945420) -- Sora no Kiseki the 1st - Advanced Recovery Medicine Set (1)
addappid(3945430) -- Sora no Kiseki the 1st - Advanced Recovery Medicine Set (2)
addappid(3945440) -- Sora no Kiseki the 1st - Advanced Recovery Medicine Set (3)
addappid(3945450) -- Sora no Kiseki the 1st - Advanced Recovery Medicine Set (4)
addappid(3945460) -- Sora no Kiseki the 1st - Advanced Recovery Medicine Set (5)
addappid(3945470) -- Sora no Kiseki the 1st - Zelam Powder Set (1)
addappid(3945480) -- Sora no Kiseki the 1st - Zelam Powder Set (2)
addappid(3945490) -- Sora no Kiseki the 1st - Zelam Powder Set (3)
addappid(3945500) -- Sora no Kiseki the 1st - Zelam Capsule Set (1)
addappid(3945510) -- Sora no Kiseki the 1st - Zelam Capsule Set (2)
addappid(3945520) -- Sora no Kiseki the 1st - Zelam Capsule Set (3)
addappid(3945550) -- Sora no Kiseki the 1st - Golden Pom Fruit Set (1)
addappid(3945560) -- Sora no Kiseki the 1st - Golden Pom Fruit Set (2)
addappid(3945570) -- Sora no Kiseki the 1st - Golden Pom Fruit Set (3)
addappid(3945580) -- Sora no Kiseki the 1st - Golden Pom Fruit Value Pack (1)
addappid(3945590) -- Sora no Kiseki the 1st - Golden Pom Fruit Value Pack (2)
addappid(3945600) -- Sora no Kiseki the 1st - Golden Pom Fruit Value Pack (3)
addappid(3945610) -- Sora no Kiseki the 1st - Droplet Set (1)
addappid(3945620) -- Sora no Kiseki the 1st - Droplet Set (2)
addappid(3945630) -- Sora no Kiseki the 1st - Droplet Set (3)
addappid(3945640) -- Sora no Kiseki the 1st - Combat Boost Pack Physical
addappid(3945650) -- Sora no Kiseki the 1st - Combat Boost Pack Magical
addappid(3945660) -- Sora no Kiseki the 1st - Free Sample Set Vol.1
addappid(3945670) -- Sora no Kiseki the 1st - Free Sample Set Vol.2
addappid(3945680) -- Sora no Kiseki the 1st - Free Sample Set Vol.3
addappid(3965850) -- Sora no Kiseki the 1st Season Pass