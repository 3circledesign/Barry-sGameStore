-- Generated Lua Manifest by Solus Bot in Morrenus Games
-- Steam App 3176060 Manifest
-- Name: Emissary Zero
-- Generated: 2025-06-05 12:52:36
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(3176060) -- Emissary Zero

-- MAIN APP DEPOTS
addappid(3176061, 1, "87ccd43a7ff83224384228a50111bc6cfee10144e93af2284c27dcdae12d5e38") -- Main Game Content (Windows Content)
setManifestid(3176061, "7193368094109870926", 0)

-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "550968249685141759", 0)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 0)
