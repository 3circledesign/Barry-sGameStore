addappid(927380) -- Yakuza Kiwami 2
-- MAIN APP DEPOTS
addappid(927381, 1, "23ab2918d89de8bcea11ba1517ea120e1c8bc8ef188f22abefeb07765362193c") -- Lotusflower Content
setManifestid(927381, "8687551471438537642", 43944475178)
addappid(927382, 1, "5fab821dbe4cb51d6cede5ab01323beb934e97d7234cd006748536c657693c54") -- Lotusflower Bin
setManifestid(927382, "8846117159153844266", 53305040)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1030500) -- Yakuza Kiwami 2 - Clan Creator Bundle