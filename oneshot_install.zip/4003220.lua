addappid(4003220) -- I woke up in the house of a fat man: he's over 30 years old and loves beer and games
-- MAIN APP DEPOTS
addappid(4003221, 1, "b10f4da8b18e4a4012a0241fe067bcdef360ea1deacf3e9979cb79965d41870a") -- Depot 4003221
--setManifestid(4003221, "8523019030800185124", 2789391817)