addappid(3831660) -- Obsessed : Night Shift
-- MAIN APP DEPOTS
addappid(3831661, 1, "0f8cfa6fe6e6a0b869fcbcfb10734b15a73d4775be453c922a307ce3f9d42623") -- Depot 3831661
--setManifestid(3831661, "7163076774412427178", 303939561)