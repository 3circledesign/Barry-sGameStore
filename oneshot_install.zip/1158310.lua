addappid(1158310, 1, "557ad61973b671765b3fa06419cd0aea2fa1690ea60a5cee5baa28525120b818") -- Crusader Kings III
-- MAIN APP DEPOTS
addappid(1158311, 1, "d2ead3e2e963a05fbe46ed87bce1375e97e07940fb0b73551acbd416d7d789f7") -- CK3 Game Content
setManifestid(1158311, "4718909281280039965", 18456974137)
addappid(1158312, 1, "d178a07d53f6aaef043e6e015c9d656307e459426598b5d568ebb2b3b82b9608") -- CK3 Windows Binaries
setManifestid(1158312, "6847876617598301174", 156732866)
addappid(1158313, 1, "28cca6706c1df3cb12bb0916470bd295e7955dbf8b58e0289eedd6548ed74fcd") -- CK3 macOS Binaries
setManifestid(1158313, "5292893659849392004", 1138987404)
addappid(1158314, 1, "5f74c6004a102908c726784d9666f0b99e0dcf4182f0d6c7f619d1a2d8f448d6") -- CK3 Linux Binaries
setManifestid(1158314, "8846370921502527463", 319950601)
addappid(1158315, 1, "5ef7e854e3cbd7d65529fcbefeffce4ac0ef29e88b86d27cee52a7690216107e") -- CK3 Launcher Windows
setManifestid(1158315, "8355345534666421034", 189877847)
addappid(1158316, 1, "2d319308690b3ea4dcf9bddf50556eb622d60c1534b8c0b99635b1411c4b7c38") -- CK3 Launcher macOS
setManifestid(1158316, "2100899916790545054", 387143771)
addappid(1158317, 1, "f469b8ff863146cdc8807b811af2798498548e8fa479d8baee48794844fbe69a") -- CK3 Launcher Linux
setManifestid(1158317, "7720695210475063296", 187934648)
-- SHARED DEPOTS (from other apps)
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- VC 2005 Redist (Shared from App 228980)
setManifestid(228981, "7613356809904826842", 5884085)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
-- DLCS WITH DEDICATED DEPOTS
-- Crusader Kings III Garments of the Holy Roman Empire (AppID: 1296730)
addappid(1296730)
addtoken(1296730, "1097817278931358754")
addappid(1296730, 1, "b6ad131a6dddf0333ec7e0519152d2036618fec07c4922d84d37fbaf067c87da") -- Crusader Kings III Garments of the Holy Roman Empire - dlc001_preorder
setManifestid(1296730, "4673314442703562503", 84848)
-- Crusader Kings III Fashion of the Abbasid Court (AppID: 1296731)
addappid(1296731)
addtoken(1296731, "3896636678119466816")
addappid(1296731, 1, "5e91c15e76962952a2ffbe32036896af3f12a1b3e2d7d85e0aa3bd5b591371f4") -- Crusader Kings III Fashion of the Abbasid Court - dlc002_sp_day1
setManifestid(1296731, "6186085975311389712", 65328)
-- Crusader Kings III Royal Court (AppID: 1303182)
addappid(1303182)
addappid(1303182, 1, "a0c0f39c8f73b18c0b6e1deeb859d6eecd1aa2206ca3f14446ad2b5d19e0d8bb") -- Crusader Kings III Royal Court - Crusader Kings III: Royal Court (1303182) Depot
setManifestid(1303182, "8349193067317801238", 23359792)
-- Crusader Kings III Northern Lords (AppID: 1303183)
addappid(1303183)
addappid(1303183, 1, "ac6a757b30c2f011d2f051972671d12edf33cf45e667631816aa4d474e4accfa") -- Crusader Kings III Northern Lords - dlc003_fp1
setManifestid(1303183, "319832865587329166", 25074458)
-- Crusader Kings III Fate of Iberia (AppID: 1303184)
addappid(1303184)
addappid(1303184, 1, "41092a88d0a8e3e850bd4869fdfec371e9e650cdd6b899830e1514b2d8aa4e60") -- Crusader Kings III Fate of Iberia - Depot 1303184
setManifestid(1303184, "5526476400820247778", 9854377)
-- Crusader Kings III Friends  Foes (AppID: 2114760)
addappid(2114760)
addappid(2114760, 1, "83b72504fb9aee8d29f7ddec0b8d8442a0c27c0a3faf006ec844a763e2347ed8") -- Crusader Kings III Friends  Foes - Depot 2114760
setManifestid(2114760, "3994555691751599121", 9199940)
-- Crusader Kings III Tours  Tournaments (AppID: 2311920)
addappid(2311920)
addappid(2311920, 1, "f23bbe66881920bd3128bcfa53a3f68585a269530fcd32b5cf5894ea6152e772") -- Crusader Kings III Tours  Tournaments - Depot 2311920
setManifestid(2311920, "369571786361796926", 30559359)
-- Crusader Kings III Elegance of the Empire (AppID: 2311930)
addappid(2311930)
addappid(2311930, 1, "307dd1f72030f402ad1847685f13aeb63b991298ccc38cb81513b53162f22974") -- Crusader Kings III Elegance of the Empire - Depot 2311930
setManifestid(2311930, "6473405525877152548", 80415)
-- Crusader Kings III Legacy of Persia (AppID: 2313540)
addappid(2313540)
addappid(2313540, 1, "73bfc84892c44a72fc1f626d89eafa482dc9039cce8101245f94de0ac49f0a6c") -- Crusader Kings III Legacy of Persia - Depot 2313540
setManifestid(2313540, "5292219204640282308", 15690475)
-- Crusader Kings III Wards  Wardens (AppID: 2313541)
addappid(2313541)
addappid(2313541, 1, "ca2c9bbbbac59f89ad2a71415477022a649d86e76d91f84db5f3e1308c5408d0") -- Crusader Kings III Wards  Wardens - Depot 2313541
setManifestid(2313541, "3449603529685425916", 6707287)
-- Crusader Kings III Creator Pack North African Attire (AppID: 2671030)
addappid(2671030)
addappid(2671030, 1, "9d19bb3c128d767ebde19658b1082953029550afad6b0371eb37a8b73d6b9835") -- Crusader Kings III Creator Pack North African Attire - Depot 2671030
setManifestid(2671030, "2257513862370412160", 100482)
-- Crusader Kings III Couture of the Capets (AppID: 2671040)
addappid(2671040)
addappid(2671040, 1, "ebaacffd86656bfa93c26fa5eca1c15e3b11d61f0d7f44962ecd3470f8889b68") -- Crusader Kings III Couture of the Capets - Depot 2671040
setManifestid(2671040, "836968934287748787", 64416)
-- Crusader Kings III Legends of the Dead (AppID: 2671060)
addappid(2671060)
addappid(2671060, 1, "55a99a7a6b4f42c4b154f1756d13a20580eb53f2d5074260db1c7f31802ce475") -- Crusader Kings III Legends of the Dead - Depot 2671060
setManifestid(2671060, "4277321347182715431", 15898541)
-- Crusader Kings III Roads to Power (AppID: 2671070)
addappid(2671070)
addappid(2671070, 1, "98957a792feb520525cb64fc2b99dce35e9da85fef8471647cff2efe3079c6df") -- Crusader Kings III Roads to Power - Depot 2671070
setManifestid(2671070, "7287565713113083837", 21073072)
-- Crusader Kings III Wandering Nobles (AppID: 2671080)
addappid(2671080)
addappid(2671080, 1, "64e40bc9a04cce7bb5af0374919cefc33d612c92878821b9ff3a6083e1b1c361") -- Crusader Kings III Wandering Nobles - Depot 2671080
setManifestid(2671080, "4340206838279069052", 82855)
-- Crusader Kings III Many Roads to Power - Comic Book (AppID: 3077630)
addappid(3077630)
addappid(3077630, 1, "03afe5bbf64b8a6dca9bb88c107cafd75e37b9b0a6f20dc93f5dfc12f4da46e7") -- Crusader Kings III Many Roads to Power - Comic Book - Depot 3077630
setManifestid(3077630, "1712003839548962838", 69250933)
-- Crusader Kings III Creator Pack West Slavic Attire (AppID: 3275760)
addappid(3275760)
addappid(3275760, 1, "c64a167b91870cb86562eac586d49817780eac22209e08d7b9978a3f23884bb0") -- Crusader Kings III Creator Pack West Slavic Attire - Depot 3275760
setManifestid(3275760, "4288366890699939411", 99060)
-- Crusader Kings III Crowns of the World (AppID: 3315500)
addappid(3315500)
addappid(3315500, 1, "326bb902af35becc78da24d218f245765d6b9f4fd116512d7af59a11197aed43") -- Crusader Kings III Crowns of the World - Depot 3315500
setManifestid(3315500, "4503344207642007609", 72114)
-- Crusader Kings III Khans of the Steppe (AppID: 3315510)
addappid(3315510)
addappid(3315510, 1, "e5950d6c9dce6f6e1bf120573842c181a5ade24429635500f86e9e30a4f53f9b") -- Crusader Kings III Khans of the Steppe - Depot 3315510
setManifestid(3315510, "3363609404063344386", 18258763)
-- Crusader Kings III Coronations (AppID: 3315520)
addappid(3315520)
addappid(3315520, 1, "c502a0bca4f49ccfeb8fc7d4e417c4c4cabcdbdc80b3b33015230ffb4781311e") -- Crusader Kings III Coronations - Depot 3315520
setManifestid(3315520, "7521553339934362737", 84060)
-- Crusader Kings III All Under Heaven (AppID: 3315530)
addappid(3315530)
addappid(3315530, 1, "8a468dd5a5093bba8f051b45c03d5b2b9603809ceaa338f623172b9c45796fa3") -- Crusader Kings III All Under Heaven - Depot 3315530
setManifestid(3315530, "8595022041963600613", 90723385)
-- Crusader Kings III Creator Pack Medieval Monuments (AppID: 3315540)
addappid(3315540)
addappid(3315540, 1, "67fe76e558dfbb3d6235797bb8fd0c7ed47591aee7bf9e759a11a2550c7a48f9") -- Crusader Kings III Creator Pack Medieval Monuments - Depot 3315540
setManifestid(3315540, "1359283799129796893", 19982507)
-- Crusader Kings III Creator Pack Arctic Attire (AppID: 3315550)
addappid(3315550)
addappid(3315550, 1, "d0ffe0a4152529a8088f9cc8908da50a1cff62ed6735944a34ada2db3bcd0ee2") -- Crusader Kings III Creator Pack Arctic Attire - Depot 3315550
setManifestid(3315550, "2840621713410264825", 1852566)
-- Crusader Kings III Creator Pack High Medieval Warfare Attire (AppID: 3315560)
addappid(3315560)
addappid(3315560, 1, "2e2efbfc8a4fab2c7da7df1b69f5fb0dcbaaac57b03156e03babd0462d902f20") -- Crusader Kings III Creator Pack High Medieval Warfare Attire - Depot 3315560
setManifestid(3315560, "5111920289037265676", 98743)
-- Crusader Kings III Creator Pack Holy Buildings (AppID: 3315570)
addappid(3315570)
addappid(3315570, 1, "64b1967e37b5dab375d76bcd85fc0bb57ca2bb7ce41bcf653fcb9e8b150b0250") -- Crusader Kings III Creator Pack Holy Buildings - Depot 3315570
setManifestid(3315570, "409066589632915157", 98734)
-- Crusader Kings III Creator Pack North Pacific Attire (AppID: 3315580)
addappid(3315580)
addappid(3315580, 1, "8a9863b7a03af1c278712db25bd7789527c599c8b6d9c39b84c7fbd0b0a2ca5a") -- Crusader Kings III Creator Pack North Pacific Attire - Depot 3315580
setManifestid(3315580, "6705959764445437481", 4625479)
-- Crusader Kings III Songs of the Realm (AppID: 3315590)
addappid(3315590)
addappid(3315590, 1, "f83e2975806db41d2d9ccb7e1d90e57834851f8aedcff4a325c76d8dedcfb321") -- Crusader Kings III Songs of the Realm - Depot 3315590
setManifestid(3315590, "867193425775422940", 35828368)
-- Crusader Kings III Creator Pack East Asian Wonders (AppID: 4232860)
addappid(4232860)
addappid(4232860, 1, "8da903c8473b9b73ed7d162d555f15fc2b69dae4d0b46f65f179216ec0c318cf") -- Crusader Kings III Creator Pack East Asian Wonders - Depot 4232860
setManifestid(4232860, "2743333143025069241", 94895)
-- Crusader Kings III Creator Pack Celestial Court Attire (AppID: 4232870)
addappid(4232870)
addappid(4232870, 1, "3d88dcaf5dae5cc78b4f34a345672015051ee4e0cf803f04ed2ec1efa11d9ae7") -- Crusader Kings III Creator Pack Celestial Court Attire - Depot 4232870
setManifestid(4232870, "6970199339967430673", 96059)
-- Crusader Kings III Symbols of Authority (AppID: 4232890)
addappid(4232890)
addappid(4232890, 1, "a5d1b14c4b644dd84406d846c84fdbf6d282b3bac55bed41a3bad79acfe26f5c") -- Crusader Kings III Symbols of Authority - Depot 4232890
setManifestid(4232890, "6242168399361031321", 69984)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2812400) -- Crusader Kings III Chapter III
addappid(3486700) -- Crusader Kings III Chapter IV
addappid(4208220) -- Crusader Kings III Subscription
addappid(4232880) -- Crusader Kings III Chapter V
-- EXCLUDED DLCS:
-- UNRELEASED DLCS (COMMENTED OUT)
-- addappid(1359040) -- Crusader Kings III: Expansion Pass (unreleased)
-- addappid(4232900) -- Crusader Kings III: By God Alone (unreleased)
-- addappid(4232910) -- Crusader Kings III: Silk & Silver (unreleased)