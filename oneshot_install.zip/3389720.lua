addappid(3389720) -- DETECTIVE - Rainy night
-- MAIN APP DEPOTS
addappid(3389721, 1, "12cfc517afe7a76d3629fcf6438e97ef20f676b5f565678d6fc20dd847d5bb53") -- Depot 3389721
--setManifestid(3389721, "7281982671868321681", 4148846680)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
--setManifestid(228988, "6645201662696499616", 29212173)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
--setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
--setManifestid(228990, "1829726630299308803", 102931551)