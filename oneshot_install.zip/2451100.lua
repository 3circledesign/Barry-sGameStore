-- 2451100's Lua and Manifest Created by Morrenus
-- Little Rocket Lab
-- Created: October 09, 2025 at 01:38:34 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2451100) -- Little Rocket Lab
-- MAIN APP DEPOTS
addappid(2451101, 1, "3817c5f556bafe1583c04eda47709f40345c13b9f42096ff4bf67378421144ff") -- Depot 2451101
--setManifestid(2451101, "351399766441438162", 1919725458)