-- 2520980's Lua and Manifest Created by Morrenus
-- VEGAS Pro Edit 21 Steam Edition
-- Created: October 02, 2025 at 05:40:33 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2520980) -- VEGAS Pro Edit 21 Steam Edition
-- MAIN APP DEPOTS
addappid(2520981, 1, "e502052e13acb17a87ff482c9181188fd01341317502ee1a1bfd0cc6a60c9fe7") -- Depot 2520981
--setManifestid(2520981, "7283677738903228025", 4133560193)