-- 3181220's Lua and Manifest Created by Morrenus
-- AV Director Life!
-- Created: October 02, 2025 at 21:21:26 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(3181220) -- AV Director Life!
-- MAIN APP DEPOTS
addappid(3181222, 1, "5961bc414641c16c702484d3f4cf3766cf313190006888cd9b8e1896f174c2f0") -- Depot 3181222
--setManifestid(3181222, "6258463783727347341", 3862031513)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
--setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
--setManifestid(228990, "1829726630299308803", 102931551)