-- 1281040's Lua and Manifest Created by Morrenus
-- Baby Steps
-- Created: October 09, 2025 at 13:27:07 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1281040) -- Baby Steps
-- MAIN APP DEPOTS
addappid(1281042, 1, "053c7e21b7936b8331deb11bbc9ae5a3b3c6df28b450220009cd8bfc91a5173b") -- Depot 1281042
--setManifestid(1281042, "5229102323678812671", 20175900828)