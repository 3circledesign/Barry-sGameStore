addappid(3425460) -- Console Shop Simulator
-- MAIN APP DEPOTS
addappid(3425461, 1, "c440f018b7251add1a180dc6c2c777e3700d716ed573b41481d0131a5c24f5b1") -- Depot 3425461
--setManifestid(3425461, "1013541080480396507", 4368156425)
-- SHARED DEPOTS (from other apps)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
--setManifestid(228990, "1829726630299308803", 102931551)