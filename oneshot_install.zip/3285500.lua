addappid(3285500, 1, "a72e9be4f0a2395e9f01c8fc97a29f9ed4d8345a0604f8e66151de58ce08a588") -- Three Kingdoms Mushouden
-- MAIN APP DEPOTS
addappid(3285501, 1, "d540ff5a3e564eb42dd7bc7fcd2767ba878e869bde88b3b99f21372cf43fe116") -- Depot 3285501
setManifestid(3285501, "9129263997121899207", 4541693692)
-- DLCS WITH DEDICATED DEPOTS
--   (AppID: 3786750)
addappid(3786750)
addappid(3786750, 1, "8ea8b93dc597304b744fb21727c260bb3f2940dde0fc68d4cce2c9c1a2cdbecf") --   - Depot 3786750
setManifestid(3786750, "2102585071659237461", 10818451)
-- Three Kingdoms Mushouden - Mushouden GUANYU (AppID: 4243340)
addappid(4243340)
addappid(4243340, 1, "57752722713cf916021e2f04f6b6defc1e7f5aa24f70b51a6ac22f976c87b40a") -- Three Kingdoms Mushouden - Mushouden GUANYU - Depot 4243340
setManifestid(4243340, "7585080945568092154", 524875436)
-- Three Kingdoms Mushouden - Mushouden LIAO (AppID: 4243370)
addappid(4243370)
addappid(4243370, 1, "ba963f04f7a4ba05544c87cae97abf780b1406d2a7e4906183e04a17e5d0ad1e") -- Three Kingdoms Mushouden - Mushouden LIAO - Depot 4243370
setManifestid(4243370, "8251698704868364907", 520962679)