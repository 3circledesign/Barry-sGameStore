-- 1435410's Lua and Manifest Created by Morrenus
-- Shrine's Legacy
-- Created: October 07, 2025 at 15:39:41 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1435410) -- Shrine's Legacy
addtoken(1435410, "14371686714910950589")
-- MAIN APP DEPOTS
addappid(1435411, 1, "5a08d19c32f6007af41ac881a5cddb9f50aab657d819f02ada069b5df66ea8d8") -- Depot 1435411
--setManifestid(1435411, "4322343166547856322", 240463505)