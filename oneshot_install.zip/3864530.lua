addappid(3864530) -- 炽澜号
-- MAIN APP DEPOTS
addappid(3864531, 1, "6c907aa6b89ce94de692460ae4ca908f3ec0fba1db2d43dd90acad4571329e03") -- Depot 3864531
--setManifestid(3864531, "7372475696696643784", 36253989683)
-- EXCLUDED DLCS:
-- DLCS EXCLUDED (MISSING DEPOT KEYS)
--  (AppID: 4051390) - missing depot keys
-- addappid(4051390)