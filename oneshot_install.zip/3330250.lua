-- Steam App 3330250 Manifest
-- Name: Ithya: Magic Studies
-- Generated: 2025-05-14 12:50:29
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3330250) -- Ithya: Magic Studies

-- MAIN APP DEPOTS
addappid(3330251, 1, "a7633b3d30636dfe1dae9b0d4f95964133d913e1bc86fef04e6300f14129dca2") -- Main Game Content (Windows Content)
setManifestid(3330251, "2157807002797518256", 0)
