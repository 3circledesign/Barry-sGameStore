addappid(402160) -- Star Command Galaxies
-- MAIN APP DEPOTS
addappid(402162, 1, "610cc935cdd6dca875913fd7a382209d875f2b3f81e9cfcba40888aa00f2b55f") -- Star Command Galaxies Windows
--setManifestid(402162, "3580094982673355771", 1782371838)
addappid(402163, 1, "ff714552b6160c9ae865fba566de8c55305d063889277177375ac92021e6cc5e") -- Star Command Galaxies Windows 32bit
--setManifestid(402163, "146128995381155277", 1772113916)