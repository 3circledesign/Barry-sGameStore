addappid(1442530) -- Outbreak Island
-- MAIN APP DEPOTS
addappid(1442531, 1, "13e1b02a1aaa02b3d7d0915d3cb23f97a310067eeb6641e418a2a91e5f036ab4") -- Depot 1442531
--setManifestid(1442531, "6848801410457066285", 16330145124)
-- SHARED DEPOTS (from other apps)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- VC 2013 Redist (Shared from App 228980)
--setManifestid(228985, "3966345552745568756", 13699237)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
--setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(4090460) -- Outbreak Island - Supporter Pack