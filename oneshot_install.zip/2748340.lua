addappid(2748340) -- Goblin Cleanup
-- MAIN APP DEPOTS
addappid(2748341, 1, "233c9add49d8a65e1f5429ff387e888d6773c93b64200f5334745da45762de2d") -- Depot 2748341
--setManifestid(2748341, "144399621647278866", 9000465518)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3908020) -- Goblin Cleanup - Exclusive Kickstarter Outfit
addappid(3908040) -- Goblin Cleanup - Halloween Skin (Kickstarter)