-- 2778850's Lua and Manifest Created by Morrenus
-- One Iced Latte With Your Breast Milk, Please!
-- Created: September 30, 2025 at 04:48:40 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 3
-- Total DLCs: 2

-- MAIN APPLICATION
addappid(2778850) -- One Iced Latte With Your Breast Milk, Please!
-- MAIN APP DEPOTS
addappid(2778851, 1, "da263295f5971d0856e89a87add4868f0da3e9b9ce3d178d226bdfb7347daee5") -- Depot 2778851
--setManifestid(2778851, "2649124815318821467", 720262672)
-- DLCS WITH DEDICATED DEPOTS
-- One Iced Latte With Your Breast Milk, Please  Hot Coffee DLC  [R-18] (AppID: 3815950)
addappid(3815950)
addappid(3815950, 1, "a7c91a62e59d54283e600ea89965fd95ed096c2734165a34468e5c0fd61ffe12") -- One Iced Latte With Your Breast Milk, Please  Hot Coffee DLC  [R-18] - Depot 3815950
--setManifestid(3815950, "591340473212244181", 371)
-- One Iced Latte With Your Breast Milk, Please  ArtBook  [Tip Box] (AppID: 3840520)
addappid(3840520)
addappid(3840520, 1, "9ec0079f8092adbab78c328133e8721a39b94df0e79bfc29f10d0614e33729d6") -- One Iced Latte With Your Breast Milk, Please  ArtBook  [Tip Box] - Depot 3840520
--setManifestid(3840520, "2721745637506923180", 129937771)